module.exports = {
	mailgun: {
		apiKey: 'key-4f5001a2537e22b8eae2d4bf95cb8350',
		domain: 'hux.com',
		fromAddress: 'machine@hux.com',
		toAddress: 'engineers@hux.com',
	},
	mongoConnectionURL: 'mongodb://pluto:8bJK3mre2gq66Ma93Kph5@portal-ssl1081-31.huxmongo.646625304.composedb.com:18867/hux?authSource=hux&ssl=true',
};