module.exports = {
	Appointments: [
		{customer: null},
		{provider: null},
		{tz:null},
		{'status.upcoming': false, 'details.end.time': {$gt: new Date()}},
		{'status.upcoming': true, 'details.end.time': {$lt: new Date()}},
	],
	users: [
		{'secret.credit': {$gt: 30000}, isAdmin: false},
		{'payout.balance': {$gt: 20000}},
		{'provider.services.$.coverage.length': 0},
	],
};