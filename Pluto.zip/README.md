Pluto combs your Mongo database for bugs.

# Required Files
- `keys.js` – a JSON file containing API keys and important configurations
- `config.js` - a JSON file containing the collections and an array of queries to check
